import express, { request, response } from 'express';

const app = express();
const port = 8080;

/* endpoint para la bbienvenida */
app.get("/Bienvenida", (request, response) => {
    response.send('<h1 style="color:blue">¡Bienvenido a mi aplicacion express!</h1>');
});

/* endpint para obtener datos de un usuario*/
app.get("/usuario", (request, response) => {
    const usuario ={
        nombre: 'ignacio',
        apellido:  'agnese',
        edad: 23,
        correo: 'ignacio.f.agnese@gmail.com'
    }
    response.json(usuario);
})

/* poner a escuchar el servidor */
app.listen( port, () => {
    console.log(`servidor escuchando el puerto ${port}`);

});